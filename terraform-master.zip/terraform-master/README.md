# terraform

By using Terraform we are creating an EC2 Insatnce in AWS environment.
